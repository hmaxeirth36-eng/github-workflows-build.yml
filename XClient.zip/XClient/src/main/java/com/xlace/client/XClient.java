package com.xlace.client;

import com.xlace.client.gui.ModMenu;
import com.xlace.client.gui.XMainMenu;
import com.xlace.client.module.Config;
import com.xlace.client.module.ModuleManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiMainMenu;
import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.client.event.GuiOpenEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import org.lwjgl.input.Keyboard;

@Mod(modid = "xclient", name = "XClient", version = "0.2.0",
        clientSideOnly = true, acceptedMinecraftVersions = "[1.8.9]")
public class XClient {
    public static ModuleManager modules;
    public static final KeyBinding MENU_KEY =
            new KeyBinding("Open Mod Menu", Keyboard.KEY_RSHIFT, "XClient");

    @Mod.EventHandler
    public void init(FMLInitializationEvent e) {
        ClientRegistry.registerKeyBinding(MENU_KEY);
        modules = new ModuleManager();
        Config.load();
        MinecraftForge.EVENT_BUS.register(this);
    }

    @SubscribeEvent
    public void onKey(InputEvent.KeyInputEvent e) {
        if (MENU_KEY.isPressed()) {
            Minecraft.getMinecraft().displayGuiScreen(new ModMenu());
        }
    }

    /** Replace the vanilla title screen with the X Client one. */
    @SubscribeEvent
    public void onGuiOpen(GuiOpenEvent e) {
        if (e.gui instanceof GuiMainMenu) e.gui = new XMainMenu();
    }
}
