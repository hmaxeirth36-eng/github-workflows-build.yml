package com.xlace.client.module.impl;

import com.xlace.client.module.BoolSetting;
import com.xlace.client.module.Module;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;

/**
 * Hold the key to look around freely. Visual only: the rotation the server
 * sees (and your movement/aim) never changes while it is active.
 */
public class FreelookModule extends Module {
    private final BoolSetting thirdPerson = bool("Third person", true);
    private boolean active;
    private float lockedYaw, lockedPitch, camYaw, camPitch;
    private int prevView;

    public FreelookModule() { super("Freelook", "Hold key to look around freely", true, Keyboard.KEY_LMENU); }

    @Override public boolean hold() { return true; }

    private static void setRot(EntityPlayerSP p, float yaw, float pitch) {
        p.rotationYaw = p.prevRotationYaw = yaw;
        p.rotationPitch = p.prevRotationPitch = pitch;
    }

    @SubscribeEvent
    public void onRender(TickEvent.RenderTickEvent e) {
        EntityPlayerSP p = mc.thePlayer;
        if (p == null) { active = false; return; }

        if (e.phase == TickEvent.Phase.START) {
            boolean want = enabled && key > 0 && Keyboard.isKeyDown(key) && mc.currentScreen == null;
            if (want && !active) {
                active = true;
                lockedYaw = p.rotationYaw;
                lockedPitch = p.rotationPitch;
                camYaw = lockedYaw;
                camPitch = lockedPitch;
                prevView = mc.gameSettings.thirdPersonView;
                if (thirdPerson.value) mc.gameSettings.thirdPersonView = 1;
            } else if (!want && active) {
                active = false;
                mc.gameSettings.thirdPersonView = prevView;
            }
            if (active) setRot(p, camYaw, camPitch); // mouse movement applies on top of the camera
        } else if (active) {
            camYaw = p.rotationYaw;
            camPitch = p.rotationPitch;
            setRot(p, lockedYaw, lockedPitch);       // game ticks see the real rotation
        }
    }
}
