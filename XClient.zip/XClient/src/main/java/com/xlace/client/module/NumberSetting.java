package com.xlace.client.module;

import java.util.Locale;

public class NumberSetting extends Setting {
    public double value;
    public final double min, max, step;

    public NumberSetting(String name, double value, double min, double max, double step) {
        super(name);
        this.min = min; this.max = max; this.step = step;
        set(value);
    }

    public void set(double v) {
        v = Math.round(v / step) * step;
        value = Math.max(min, Math.min(max, v));
    }

    public String display() {
        return step >= 1 ? String.valueOf((int) Math.round(value))
                : String.format(Locale.US, "%.1f", value);
    }
}
