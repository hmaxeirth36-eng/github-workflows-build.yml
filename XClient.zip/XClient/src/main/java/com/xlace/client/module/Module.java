package com.xlace.client.module;

import net.minecraft.client.Minecraft;

import java.util.ArrayList;
import java.util.List;

public abstract class Module {
    public final String name, desc;
    public boolean enabled;
    public int x, y;
    /** LWJGL key code, 0 = none. Toggles the module, or is the "hold" key if hold() is true. */
    public int key;
    public final List<Setting> settings = new ArrayList<Setting>();
    protected final Minecraft mc = Minecraft.getMinecraft();

    public Module(String name, String desc, boolean enabled, int key) {
        this.name = name; this.desc = desc; this.enabled = enabled; this.key = key;
    }

    public boolean hold() { return false; }
    public void toggle() { enabled = !enabled; }

    protected BoolSetting bool(String n, boolean d) {
        BoolSetting s = new BoolSetting(n, d);
        settings.add(s);
        return s;
    }

    protected NumberSetting num(String n, double d, double min, double max, double step) {
        NumberSetting s = new NumberSetting(n, d, min, max, step);
        settings.add(s);
        return s;
    }
}
