package com.xlace.client.gui;

import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiMultiplayer;
import net.minecraft.client.gui.GuiOptions;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiSelectWorld;
import net.minecraft.client.renderer.GlStateManager;

import java.io.IOException;

/** X Client title screen (replaces the vanilla one). */
public class XMainMenu extends GuiScreen {
    @Override
    public void initGui() {
        buttonList.clear();
        int bx = width / 2 - 100, by = height / 2 - 4;
        buttonList.add(new FlatButton(0, bx, by, 200, 24, "Singleplayer"));
        buttonList.add(new FlatButton(1, bx, by + 28, 200, 24, "Multiplayer"));
        buttonList.add(new FlatButton(2, bx, by + 56, 200, 24, "Mod Menu"));
        buttonList.add(new FlatButton(3, bx, by + 84, 98, 24, "Options"));
        buttonList.add(new FlatButton(4, bx + 102, by + 84, 98, 24, "Quit"));
    }

    @Override
    protected void actionPerformed(GuiButton b) throws IOException {
        switch (b.id) {
            case 0: mc.displayGuiScreen(new GuiSelectWorld(this)); break;
            case 1: mc.displayGuiScreen(new GuiMultiplayer(this)); break;
            case 2: mc.displayGuiScreen(new ModMenu()); break;
            case 3: mc.displayGuiScreen(new GuiOptions(this, mc.gameSettings)); break;
            case 4: mc.shutdown(); break;
        }
    }

    @Override
    public void drawScreen(int mx, int my, float pt) {
        drawGradientRect(0, 0, width, height, 0xFF0B0D18, 0xFF1B1F3A);

        GlStateManager.pushMatrix();
        GlStateManager.translate(width / 2f, height / 2f - 104, 0f);
        GlStateManager.scale(8f, 8f, 1f);
        drawCenteredString(fontRendererObj, "X", 0, 0, 0xFFFF3B3B);
        GlStateManager.popMatrix();

        GlStateManager.pushMatrix();
        GlStateManager.translate(width / 2f, height / 2f - 36, 0f);
        GlStateManager.scale(2.5f, 2.5f, 1f);
        drawCenteredString(fontRendererObj, "CLIENT", 0, 0, 0xFFFFFF);
        GlStateManager.popMatrix();

        drawString(fontRendererObj, "X Client 0.2.0  |  Minecraft 1.8.9", 6, height - 12, Theme.MUTED);
        super.drawScreen(mx, my, pt);
    }

    @Override
    public boolean doesGuiPauseGame() { return false; }
}
