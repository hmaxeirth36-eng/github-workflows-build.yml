package com.xlace.client.module.impl;

import com.xlace.client.module.HudModule;
import net.minecraft.client.Minecraft;

public class FpsModule extends HudModule {
    public FpsModule() { super("FPS", "Show your FPS", true, 4, 4); }
    @Override protected String text() { return "FPS: " + Minecraft.getDebugFPS(); }
}
