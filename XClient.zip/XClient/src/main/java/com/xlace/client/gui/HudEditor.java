package com.xlace.client.gui;

import com.xlace.client.XClient;
import com.xlace.client.module.Config;
import com.xlace.client.module.HudModule;
import com.xlace.client.module.Module;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiScreen;

import java.io.IOException;
import java.util.List;

/** Drag HUD elements around. ESC to save and close. */
public class HudEditor extends GuiScreen {
    private HudModule drag;
    private int offX, offY;

    private static int w(HudModule m) { return (int) (m.width() * m.getScale()); }
    private static int h(HudModule m) { return (int) (m.height() * m.getScale()); }

    @Override
    public void drawScreen(int mx, int my, float pt) {
        drawRect(0, 0, width, height, 0x66000000);
        drawCenteredString(fontRendererObj, "Drag HUD elements  -  ESC to save", width / 2, 10, Theme.WHITE);
        for (Module m : XClient.modules.all) {
            if (!(m instanceof HudModule) || !m.enabled) continue;
            HudModule hm = (HudModule) m;
            hm.renderAt();
            boolean hot = hm == drag || Theme.in(mx, my, hm.x, hm.y, w(hm), h(hm));
            int c = hot ? Theme.ACCENT : 0x80FFFFFF;
            int x1 = hm.x - 1, y1 = hm.y - 1, x2 = hm.x + w(hm) + 1, y2 = hm.y + h(hm) + 1;
            Gui.drawRect(x1, y1, x2, y1 + 1, c);
            Gui.drawRect(x1, y2 - 1, x2, y2, c);
            Gui.drawRect(x1, y1, x1 + 1, y2, c);
            Gui.drawRect(x2 - 1, y1, x2, y2, c);
        }
    }

    @Override
    protected void mouseClicked(int mx, int my, int btn) throws IOException {
        if (btn != 0) return;
        List<Module> all = XClient.modules.all;
        for (int i = all.size() - 1; i >= 0; i--) {
            Module m = all.get(i);
            if (!(m instanceof HudModule) || !m.enabled) continue;
            HudModule hm = (HudModule) m;
            if (Theme.in(mx, my, hm.x, hm.y, w(hm), h(hm))) {
                drag = hm;
                offX = mx - hm.x;
                offY = my - hm.y;
                return;
            }
        }
    }

    @Override
    protected void mouseClickMove(int mx, int my, int btn, long t) {
        if (drag == null) return;
        drag.x = Math.max(0, Math.min(width - w(drag), mx - offX));
        drag.y = Math.max(0, Math.min(height - h(drag), my - offY));
    }

    @Override
    protected void mouseReleased(int mx, int my, int state) {
        drag = null;
    }

    @Override
    public void onGuiClosed() { Config.save(); }

    @Override
    public boolean doesGuiPauseGame() { return false; }
}
