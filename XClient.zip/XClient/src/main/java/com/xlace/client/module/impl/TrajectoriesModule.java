package com.xlace.client.module.impl;

import com.xlace.client.module.BoolSetting;
import com.xlace.client.module.Module;
import com.xlace.client.module.NumberSetting;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderGlobal;
import net.minecraft.entity.Entity;
import net.minecraft.item.*;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.Vec3;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;

import java.util.ArrayList;
import java.util.List;

/** Predicts where a bow arrow / egg / snowball / pearl will land (vanilla 1.8.9 physics). */
public class TrajectoriesModule extends Module {
    private final BoolSetting arrows = bool("Bow", true);
    private final BoolSetting throwables = bool("Egg / Snowball / Pearl", true);
    private final BoolSetting marker = bool("Landing marker", true);
    private final NumberSetting lineWidth = num("Line width", 2, 1, 5, 1);

    public TrajectoriesModule() { super("Trajectories", "Line showing where a throw lands", false, 0); }

    @SubscribeEvent
    public void onWorld(RenderWorldLastEvent e) {
        EntityPlayerSP p = mc.thePlayer;
        if (!enabled || p == null || mc.theWorld == null || p.getHeldItem() == null) return;
        Item item = p.getHeldItem().getItem();

        double speed, gravity;
        if (item instanceof ItemBow && arrows.value) {
            if (!p.isUsingItem()) return;
            float f = p.getItemInUseDuration() / 20f;
            f = (f * f + f * 2f) / 3f;
            if (f < 0.1f) return;
            if (f > 1f) f = 1f;
            speed = f * 3.0; gravity = 0.05;
        } else if ((item instanceof ItemSnowball || item instanceof ItemEgg || item instanceof ItemEnderPearl)
                && throwables.value) {
            speed = 1.5; gravity = 0.03;
        } else return;

        float pt = e.partialTicks;
        double yaw = Math.toRadians(p.prevRotationYaw + (p.rotationYaw - p.prevRotationYaw) * pt);
        double pitch = Math.toRadians(p.prevRotationPitch + (p.rotationPitch - p.prevRotationPitch) * pt);
        double x = p.lastTickPosX + (p.posX - p.lastTickPosX) * pt - Math.cos(yaw) * 0.16;
        double y = p.lastTickPosY + (p.posY - p.lastTickPosY) * pt + p.getEyeHeight() - 0.1;
        double z = p.lastTickPosZ + (p.posZ - p.lastTickPosZ) * pt - Math.sin(yaw) * 0.16;
        double mx = -Math.sin(yaw) * Math.cos(pitch) * speed;
        double my = -Math.sin(pitch) * speed;
        double mz = Math.cos(yaw) * Math.cos(pitch) * speed;

        List<double[]> pts = new ArrayList<double[]>();
        pts.add(new double[]{x, y, z});
        Vec3 hit = null;
        for (int i = 0; i < 300; i++) {
            double nx = x + mx, ny = y + my, nz = z + mz;
            MovingObjectPosition r = mc.theWorld.rayTraceBlocks(new Vec3(x, y, z), new Vec3(nx, ny, nz), false, true, false);
            if (r != null) {
                hit = r.hitVec;
                pts.add(new double[]{hit.xCoord, hit.yCoord, hit.zCoord});
                break;
            }
            x = nx; y = ny; z = nz;
            pts.add(new double[]{x, y, z});
            mx *= 0.99; my *= 0.99; mz *= 0.99;
            my -= gravity;
            if (y < 0) break;
        }

        Entity rv = mc.getRenderViewEntity();
        double cx = rv.lastTickPosX + (rv.posX - rv.lastTickPosX) * pt;
        double cy = rv.lastTickPosY + (rv.posY - rv.lastTickPosY) * pt;
        double cz = rv.lastTickPosZ + (rv.posZ - rv.lastTickPosZ) * pt;

        GlStateManager.pushMatrix();
        GlStateManager.disableTexture2D();
        GlStateManager.disableLighting();
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GL11.glLineWidth((float) lineWidth.value);
        GL11.glColor4f(0.36f, 0.55f, 1f, 0.9f);
        GL11.glBegin(GL11.GL_LINE_STRIP);
        for (double[] q : pts) GL11.glVertex3d(q[0] - cx, q[1] - cy, q[2] - cz);
        GL11.glEnd();
        if (hit != null && marker.value) {
            double hx = hit.xCoord - cx, hy = hit.yCoord - cy, hz = hit.zCoord - cz;
            RenderGlobal.drawOutlinedBoundingBox(
                    new AxisAlignedBB(hx - 0.2, hy - 0.2, hz - 0.2, hx + 0.2, hy + 0.2, hz + 0.2),
                    255, 80, 80, 255);
        }
        GL11.glLineWidth(1f);
        GlStateManager.color(1f, 1f, 1f, 1f);
        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
        GlStateManager.enableLighting();
        GlStateManager.popMatrix();
    }
}
