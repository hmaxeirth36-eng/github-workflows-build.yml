package com.xlace.client.module;

import com.xlace.client.gui.HudEditor;
import com.xlace.client.module.impl.*;
import net.minecraft.client.Minecraft;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import org.lwjgl.input.Keyboard;

import java.util.ArrayList;
import java.util.List;

public class ModuleManager {
    public final List<Module> all = new ArrayList<Module>();
    private final Minecraft mc = Minecraft.getMinecraft();

    public ModuleManager() {
        all.add(new FpsModule());
        all.add(new PingModule());
        all.add(new CpsModule());
        all.add(new KeystrokesModule());
        all.add(new ToggleSprintModule());
        all.add(new FreelookModule());
        all.add(new ZoomModule());
        all.add(new CpsLimiterModule());
        all.add(new TntTimerModule());
        all.add(new TrajectoriesModule());
        for (Module m : all) MinecraftForge.EVENT_BUS.register(m);
        MinecraftForge.EVENT_BUS.register(this);
    }

    @SubscribeEvent
    public void onKey(InputEvent.KeyInputEvent e) {
        if (!Keyboard.getEventKeyState() || mc.currentScreen != null) return;
        int k = Keyboard.getEventKey();
        for (Module m : all) {
            if (!m.hold() && m.key != 0 && m.key == k) {
                m.toggle();
                Config.save();
            }
        }
    }

    @SubscribeEvent
    public void onOverlay(RenderGameOverlayEvent.Post e) {
        if (e.type != RenderGameOverlayEvent.ElementType.ALL) return;
        if (mc.gameSettings.hideGUI || mc.gameSettings.showDebugInfo) return;
        if (mc.currentScreen instanceof HudEditor) return;
        for (Module m : all) {
            if (m.enabled && m instanceof HudModule) ((HudModule) m).renderAt();
        }
    }
}
