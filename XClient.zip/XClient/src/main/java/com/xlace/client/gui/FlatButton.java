package com.xlace.client.gui;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiButton;

public class FlatButton extends GuiButton {
    public FlatButton(int id, int x, int y, int w, int h, String text) {
        super(id, x, y, w, h, text);
    }

    @Override
    public void drawButton(Minecraft mc, int mx, int my) {
        if (!visible) return;
        hovered = Theme.in(mx, my, xPosition, yPosition, width, height);
        Theme.rrect(xPosition, yPosition, xPosition + width, yPosition + height,
                hovered ? 0xFF2E3552 : 0xFF1E2030);
        if (hovered) Gui.drawRect(xPosition + 1, yPosition + height - 2, xPosition + width - 1, yPosition + height, Theme.ACCENT);
        drawCenteredString(mc.fontRendererObj, displayString, xPosition + width / 2,
                yPosition + (height - 8) / 2, 0xFFFFFF);
    }
}
