# XClient 0.2 (Forge 1.8.9)

Build with GitHub Actions (see workflow in the chat) or locally with JDK 8 + Gradle 7.6:
    gradle build
The jar ends up in build/libs/XClient-0.2.0.jar -> put it in the mods folder of a Forge 1.8.9 profile.

Right Shift = mod menu (also "Mod Menu" on the title screen).
Freelook = hold Left Alt, Zoom = hold C (rebind in the mod menu).
Config: .minecraft/config/xclient.json
